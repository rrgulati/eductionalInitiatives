export interface Message {
  user: string;
  message: string;
  id: string;
}
