export interface ActiveUser {
    activeUser: {
        id: string,
        username: string
    }
}