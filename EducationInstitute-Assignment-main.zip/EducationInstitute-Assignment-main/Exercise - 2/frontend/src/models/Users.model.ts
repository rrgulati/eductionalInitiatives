export interface User {
    username: string;
    roomId: string;
}